class PizzaOrder():
    def __init__(self, size, toppings, delivery):
        self.size = size
        self.toppings = toppings
        self.delivery = delivery

    def calculate_base_price(self):
        size_prices = [3.25,5.5,7.15]
        topping_prices = [0.75, 1.35,2.0]
        base_price = size_prices[self.size] + topping_prices[len(self.toppings)-1]

        return base_price
    
    def discount(self):
        base_price = self.calculate_base_price()
        if base_price > 20:
            discount =base_price * 0.1  # Apply a 10% discount
            return discount
        else:
            return 0

    def delivery_fee(self):
        if self.delivery_fee == True:
            return 2.5
        else:
            return 0

    def total_price(self):
        return self.calculate_base_price() - self.discount() + self.delivery_fee()

    def __str__(self):
        return f"Pizza Order: Size - {self.size}, Toppings - {', '.join(self.toppings)}, Price - ${self.calculate_price():.2f}"

Order1 = PizzaOrder(1, ['pepperoni', 'mushrooms'], True)
print(Order1.calculate_base_price())
print(Order1.discount())
print(Order1.delivery_fee())
print(Order1.total_price())